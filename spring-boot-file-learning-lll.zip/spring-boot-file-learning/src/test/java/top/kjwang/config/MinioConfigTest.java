package top.kjwang.config;

import io.minio.ObjectWriteResponse;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author kjwang
 * @date 2023/4/10 15:47
 * @description MinioConfigTest
 */

@SpringBootTest
@Slf4j
class MinioConfigTest {

    @Resource
    private MinioConfig minIoConfig;

    @Test
    void makeBucket() throws Exception {
        minIoConfig.makeBucket("hello");
    }

    @Test
    void uploadObject() throws Exception {
        ObjectWriteResponse response = minIoConfig.uploadObject("hello","imgage/test.png","/Users/wangkaijie/Desktop/cat.png");
        log.info(response.object());
    }

    @Test
    void putObject() throws Exception {
    }

    @Test
    void removeObject() throws Exception {
        minIoConfig.removeObject("hello","imgage/test.png");
    }
}